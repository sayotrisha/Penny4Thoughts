package com.mobdeve.s12.rebenque.paula.mco

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class Act3LogIn : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.act_login)
    }
}